import { School } from "./School";
import { College } from "./College";
import { Iit } from "./Iit";
import { YouTube } from "./YouTube";
import { FirstInternship } from "./FirstInternship";
import { SecondInternship } from "./SecondInternship";

export { School, College, Iit, YouTube, FirstInternship, SecondInternship };
