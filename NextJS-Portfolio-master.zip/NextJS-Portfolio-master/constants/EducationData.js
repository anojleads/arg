export const EducationData = [
    {
        name: "Bachelor of Science",
        image:
            "http://res.cloudinary.com/dhixp5pnk/image/upload/v1696219056/edekjqivqlnsyg8pfmxw.png",
        schoolOrCollege: "GOVERNMENT COLLEGE, KOTA",
        fromTo: "2021 - 2022",
        statusOrPrecentage: "Dropped in second year",
    },
    {
        name: "Senior Secondary Examination",
        image:
            "http://res.cloudinary.com/dhixp5pnk/image/upload/v1696219649/jkjfvdlxjntnyrxs57ia.png",
        schoolOrCollege: "SWAMI TEONRAM ALOK SR. SEC. SCHOOL DADABARI, KOTA",
        fromTo: "2021",
        statusOrPrecentage: "96.80 %",
    },
    {
        name: "Secondary Examination",
        image:
            "http://res.cloudinary.com/dhixp5pnk/image/upload/v1696219649/tnverjapfr4slg7fnfcw.png",
        schoolOrCollege: "A.V.M. SECONDARY SCHOOL, RAWATBHATA",
        fromTo: "2019",
        statusOrPrecentage: "93.33%",
    },
];